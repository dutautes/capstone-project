document.addEventListener("DOMContentLoaded", function () {
    const searchBox = document.getElementById("searchBox");
    const destinationCards = document.querySelectorAll(".card");

    searchBox.addEventListener("input", function () {
        const searchText = searchBox.value.toLowerCase();

        destinationCards.forEach(card => {
            const title = card.querySelector(".card-title").textContent.toLowerCase();
            if (title.includes(searchText)) {
                card.parentElement.style.display = "block";
            } else {
                card.parentElement.style.display = "none";
            }
        });
    });
});
